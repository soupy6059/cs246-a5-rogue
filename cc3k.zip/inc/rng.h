#ifndef __rng__
#define __rng__

int getRand(int l, int u); // [l,u)

void initRand(int seed = 0);

#endif
